package com.android.smartnew.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.smartnew.R;

import org.jetbrains.annotations.Nullable;


public class HomeFragment extends Fragment {
     private Button sub1;
   private CheckedTextView checkBox1,checkBox2;
   public TextView editText;
   String bfst;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_home,container,false);
        sub1=(Button) view.findViewById(R.id.btn1);
        checkBox1 = (CheckedTextView) view.findViewById(R.id.checkbox1);
        checkBox2 = (CheckedTextView) view.findViewById(R.id.checkbox2);
        editText=(TextView) view.findViewById(R.id.bfast);
        checkBox1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox1.toggle();
            }
        });
        checkBox2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox2.toggle();
            }
        });
        /*
        sub1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               bfst = editText.getText().toString();
               Intent intent = new Intent(view.getContext(),UserProfile.class);
                Bundle b = new Bundle();
               b.putString("BreakFast",bfst);
               intent.putExtras(b);
                startActivity(intent);

            }
        });*/
        return view;




    }

}
