package com.android.smartnew.ui.vap;

import androidx.fragment.app.Fragment;

public class VAPFragment extends Fragment {

}