package com.android.smartnew.ui.slideshow;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.smartnew.R;

import org.jetbrains.annotations.Nullable;

public class SlideshowFragment extends Fragment {
    private CheckedTextView checkBox7,checkBox8,checkBox9;
    private Button sub3;
    public TextView editText2;
    String dner;
    @Nullable
    @Override
    public View onCreateView(@NonNull final LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view2=inflater.inflate(R.layout.fragment_slideshow,container,false);
        sub3=(Button) view2.findViewById(R.id.btn3);
        checkBox7 = (CheckedTextView) view2.findViewById(R.id.checkbox6);
        checkBox8 = (CheckedTextView) view2.findViewById(R.id.checkbox7);
        checkBox9 = (CheckedTextView) view2.findViewById(R.id.checkbox8);

        editText2 = (TextView) view2.findViewById(R.id.deener);
        checkBox7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox7.toggle();
            }
        });
        checkBox8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox8.toggle();
            }
        });
        checkBox9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox9.toggle();
            }
        });
        /*sub3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dner = editText2.getText().toString();
                Intent intent = new Intent(view.getContext(),UserProfile.class);
                Bundle b = new Bundle();
                intent.putExtra("Dner",dner);
                intent.putExtras(b);
                startActivity(intent);

            }
        });*/
         return view2;
    }
}
