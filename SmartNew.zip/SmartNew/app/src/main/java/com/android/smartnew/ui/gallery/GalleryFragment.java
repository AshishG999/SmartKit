package com.android.smartnew.ui.gallery;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.smartnew.R;

import org.jetbrains.annotations.Nullable;

//import android.support.annotation.NonNull;


public class GalleryFragment extends Fragment {
    private CheckedTextView checkBox3,checkBox4,checkBox5;
    private Button sub2;
    public TextView editText1;
    String lnch;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view1=inflater.inflate(R.layout.fragment_gallery,container,false);
        sub2=(Button) view1.findViewById(R.id.btn2);
        checkBox3 = (CheckedTextView) view1.findViewById(R.id.checkbox3);
        checkBox4 = (CheckedTextView) view1.findViewById(R.id.checkbox4);
        checkBox5 = (CheckedTextView) view1.findViewById(R.id.checkbox5);

        editText1 = (TextView) view1.findViewById(R.id.lunch1);
        checkBox3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox3.toggle();
            }
        });
        checkBox4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox4.toggle();
            }
        });
        checkBox5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkBox5.toggle();
            }
        });
        //sub2.setOnClickListener(new View.OnClickListener() {
           // @Override
           /* public void onClick(View view) {
                lnch = editText1.getText().toString();
                Intent intent = new Intent(view.getContext(), .class);
                Bundle b = new Bundle();
                intent.putExtra("lunch",lnch);
                intent.putExtras(b);
                startActivity(intent);

            }
        });*/
        return view1;
    }
}
